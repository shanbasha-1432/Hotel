const cartSchema = require('../models/cartschemamain');

const decreasequantity = async (req, res) => {
    const { itemId } = req.params;
    try {
        const cart = await cartSchema.findOne({ itemId });
        cart.quantity -= 1;
        if (cart.quantity === 0) {
            await cartSchema.deleteOne({ itemId: req.params.itemId });
            return res.status(200).json({ message: 'Item removed from cart' });
        }
        await cart.save();
        res.status(200).json({ message: 'Item quantity decreased', cart });
    } catch (error) {
        res.status(500).json({ message: 'Error processing request', error });
    }
}




module.exports = decreasequantity;