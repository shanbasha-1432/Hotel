const cartSchema = require('../models/cartschemamain');

const increasequantity = async (req, res) => {
    const { itemId } = req.params;
    try {
        const cart = await cartSchema.findOne({ itemId });
        cart.quantity += 1;
        await cart.save();
        res.status(200).json({ message: 'Item quantity increased', cart });
    } catch (error) {
        res.status(500).json({ message: 'Error processing request', error });
    }
}


module.exports = increasequantity;