const cartSchema = require('../models/cartschemamain');

const clearcart = async (req, res) => {
    try {
        await cartSchema.deleteMany();
        res.status(200).json({ message: 'Cart cleared' });
    } catch (error) {
        res.status(500).json({ message: 'Error processing request', error });
    }
}


module.exports = clearcart;