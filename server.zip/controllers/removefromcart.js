const cartSchema = require('../models/cartschemamain');

const removefromcart = async (req, res) => {
    const { itemId } = req.params;
    try {
        await cartSchema.deleteOne({ itemId });
        res.status(200).json({ message: 'Item removed from cart' });
    } catch (error) {
        res.status(500).json({ message: 'Error processing request', error });
    }
}

module.exports = removefromcart;