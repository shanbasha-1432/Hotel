const addCartItem = require('../controllers/addtocart');
const showcart = require('../controllers/showcart');
const increasequantity = require('../controllers/increasequantity');
const decreasequantity = require('../controllers/decreasequantity');
const removefromcart = require('../controllers/removefromcart'); 
const clearcart = require('../controllers/clearcart');
const express = require('express');
const router = express.Router();

router.post('/add',addCartItem);
router.post('/show',showcart);
router.post('/increase/:itemId',increasequantity);
router.post('/decrease/:itemId',decreasequantity);
router.post('/remove/:itemId',removefromcart);
router.post('/clear',clearcart);

module.exports = router;