const CartSchema = require('../models/cartschemamain');

const cartdata = async (req, res) => {
        const { itemId, name, price, quantity,category,image } = req.body;
        cart = new CartSchema({
            itemId,
            name,
            price,
            quantity,
            category,
            image
        });
        try {
            await cart.save();
            res.status(201).json({ message: 'Item added to cart', cart });
        } catch (error) {
            res.status(500).json({ message: 'Error processing request', error });
        }
    }
module.exports =  cartdata ;
